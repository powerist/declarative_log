#!/bin/bash
rm -f behaviorlog statelog
find ./ -name "*.pyc" -print -exec rm -f {} \;
find ./ -name "*.pyo" -print -exec rm -f {} \;
