#!/usr/bin/python

import tarfile

