presentation Package
====================

:mod:`textsummary` Module
-------------------------

.. automodule:: framework.presentation.textsummary
    :members:
    :undoc-members:

